from .config import global_config

__all__ = [
    "global_config",
]
