# Configure logger

from src.common.logger import get_logger

logger = get_logger("lpmm")
